export const PRODUCTS = [
    { name: "Typing Practice", link: "#" },
    { name: "Typing Tests", link: "#" },
    { name: "Typing Games", link: "#" },
    {name:"Typing Tutorials", link: '#'},
    {name:"Speed Improvement Tools", link: '#'},


  ];
  export const RESOURCES = [
    { name: "Typing Tips and Techniques", link: "#" },
    { name: "Typing Speed Challenge", link: "#" },
    { name: "Typing Certifications", link: "#" },
    { name: "Typing Blogs", link: "#" },
    { name: "Typing Practice Sheets", link: "#" },
  ];
  export const COMPANY = [
    { name: "About Us", link: "#" },
    { name: "Contact Us", link: "#" },
    { name: "Testimonials", link: "#" },
    { name: "Careers", link: "#" },
    { name: "FAQs", link: "#" },
  ];
  export const SUPPORT = [
    { name: "Documentation", link: "#" },
    { name: "Tutorials & guides", link: "#" },
    { name: "Blogs", link: "#" },
    { name: "Open-source", link: "#" },
  ];
  
  export const Icons = [
    { name: "logo-facebook", link: "#" },
    { name: "logo-twitter", link: "#" },
    { name: "logo-github", link: "#" },
    { name: "logo-linkedin", link: "#" },
    { name: "logo-instagram", link: "#" },
  ];