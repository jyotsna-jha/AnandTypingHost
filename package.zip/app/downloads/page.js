import DownloadsComponent from "@/components/Downloads/DownloadsComponent";

const HomePage = () => {
  return (
    <div>
      <DownloadsComponent />
    </div>
  );
};

export default HomePage;
